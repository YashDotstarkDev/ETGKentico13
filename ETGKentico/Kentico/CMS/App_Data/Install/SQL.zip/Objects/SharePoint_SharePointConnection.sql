SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SharePoint_SharePointConnection](
	[SharePointConnectionID] [int] IDENTITY(1,1) NOT NULL,
	[SharePointConnectionGUID] [uniqueidentifier] NOT NULL,
	[SharePointConnectionSiteID] [int] NOT NULL,
	[SharePointConnectionSiteUrl] [nvarchar](512) NOT NULL,
	[SharePointConnectionDisplayName] [nvarchar](100) NOT NULL,
	[SharePointConnectionName] [nvarchar](100) NOT NULL,
	[SharePointConnectionUserName] [nvarchar](100) NULL,
	[SharePointConnectionPassword] [nvarchar](100) NULL,
	[SharePointConnectionLastModified] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_SharePoint_SharePointConnection] PRIMARY KEY CLUSTERED 
(
	[SharePointConnectionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_SharePoint_SharePointConnection_SharePointConnectionSiteID] ON [dbo].[SharePoint_SharePointConnection]
(
	[SharePointConnectionSiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[SharePoint_SharePointConnection]  WITH CHECK ADD  CONSTRAINT [FK_SharePoint_SharePointConnection_CMS_Site] FOREIGN KEY([SharePointConnectionSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[SharePoint_SharePointConnection] CHECK CONSTRAINT [FK_SharePoint_SharePointConnection_CMS_Site]
GO
