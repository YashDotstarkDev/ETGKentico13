SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Analytics_CampaignAsset](
	[CampaignAssetID] [int] IDENTITY(1,1) NOT NULL,
	[CampaignAssetGuid] [uniqueidentifier] NOT NULL,
	[CampaignAssetLastModified] [datetime2](7) NOT NULL,
	[CampaignAssetAssetGuid] [uniqueidentifier] NOT NULL,
	[CampaignAssetCampaignID] [int] NOT NULL,
	[CampaignAssetType] [nvarchar](200) NOT NULL,
 CONSTRAINT [PK_Analytics_CampaignAsset] PRIMARY KEY CLUSTERED 
(
	[CampaignAssetID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_Analytics_CampaignAsset_CampaignAssetCampaignID] ON [dbo].[Analytics_CampaignAsset]
(
	[CampaignAssetCampaignID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[Analytics_CampaignAsset] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignAsset_CampaignAssetGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [CampaignAssetGuid]
GO
ALTER TABLE [dbo].[Analytics_CampaignAsset] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignAsset_CampaignAssetLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [CampaignAssetLastModified]
GO
ALTER TABLE [dbo].[Analytics_CampaignAsset] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignAsset_CampaignAssetAssetGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [CampaignAssetAssetGuid]
GO
ALTER TABLE [dbo].[Analytics_CampaignAsset] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignAsset_CampaignAssetCampaignID]  DEFAULT ((0)) FOR [CampaignAssetCampaignID]
GO
ALTER TABLE [dbo].[Analytics_CampaignAsset] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignAsset_CampaignAssetType]  DEFAULT (N'') FOR [CampaignAssetType]
GO
ALTER TABLE [dbo].[Analytics_CampaignAsset]  WITH CHECK ADD  CONSTRAINT [FK_Analytics_CampaignAsset_CampaignAssetCampaignID_Analytics_Campaign] FOREIGN KEY([CampaignAssetCampaignID])
REFERENCES [dbo].[Analytics_Campaign] ([CampaignID])
GO
ALTER TABLE [dbo].[Analytics_CampaignAsset] CHECK CONSTRAINT [FK_Analytics_CampaignAsset_CampaignAssetCampaignID_Analytics_Campaign]
GO
