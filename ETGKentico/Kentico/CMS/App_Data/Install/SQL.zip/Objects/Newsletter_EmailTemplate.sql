SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Newsletter_EmailTemplate](
	[TemplateID] [int] IDENTITY(1,1) NOT NULL,
	[TemplateDisplayName] [nvarchar](250) NOT NULL,
	[TemplateName] [nvarchar](250) NOT NULL,
	[TemplateSiteID] [int] NOT NULL,
	[TemplateType] [nvarchar](50) NOT NULL,
	[TemplateGUID] [uniqueidentifier] NOT NULL,
	[TemplateLastModified] [datetime2](7) NOT NULL,
	[TemplateSubject] [nvarchar](450) NULL,
	[TemplateThumbnailGUID] [uniqueidentifier] NULL,
	[TemplateDescription] [nvarchar](max) NULL,
	[TemplateIconClass] [nvarchar](200) NULL,
	[TemplateCode] [nvarchar](max) NULL,
	[TemplateInlineCSS] [bit] NOT NULL,
 CONSTRAINT [PK_Newsletter_EmailTemplate] PRIMARY KEY NONCLUSTERED 
(
	[TemplateID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE CLUSTERED INDEX [IX_Newsletter_EmailTemplate_TemplateSiteID_TemplateDisplayName] ON [dbo].[Newsletter_EmailTemplate]
(
	[TemplateSiteID] ASC,
	[TemplateDisplayName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Newsletter_EmailTemplate_TemplateSiteID_TemplateName] ON [dbo].[Newsletter_EmailTemplate]
(
	[TemplateSiteID] ASC,
	[TemplateName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[Newsletter_EmailTemplate] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailTemplate_TemplateDisplayName]  DEFAULT ('') FOR [TemplateDisplayName]
GO
ALTER TABLE [dbo].[Newsletter_EmailTemplate] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailTemplate_TemplateName]  DEFAULT ('') FOR [TemplateName]
GO
ALTER TABLE [dbo].[Newsletter_EmailTemplate] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailTemplate_TemplateType]  DEFAULT ('') FOR [TemplateType]
GO
ALTER TABLE [dbo].[Newsletter_EmailTemplate] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailTemplate_TemplateIconClass]  DEFAULT (N'icon-accordion') FOR [TemplateIconClass]
GO
ALTER TABLE [dbo].[Newsletter_EmailTemplate] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailTemplate_TemplateInlineCSS]  DEFAULT ((0)) FOR [TemplateInlineCSS]
GO
ALTER TABLE [dbo].[Newsletter_EmailTemplate]  WITH CHECK ADD  CONSTRAINT [FK_Newsletter_EmailTemplate_TemplateSiteID_CMS_Site] FOREIGN KEY([TemplateSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[Newsletter_EmailTemplate] CHECK CONSTRAINT [FK_Newsletter_EmailTemplate_TemplateSiteID_CMS_Site]
GO
