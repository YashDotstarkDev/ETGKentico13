SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COM_Collection](
	[CollectionID] [int] IDENTITY(1,1) NOT NULL,
	[CollectionDisplayName] [nvarchar](200) NOT NULL,
	[CollectionName] [nvarchar](200) NOT NULL,
	[CollectionDescription] [nvarchar](max) NULL,
	[CollectionSiteID] [int] NOT NULL,
	[CollectionEnabled] [bit] NOT NULL,
	[CollectionGuid] [uniqueidentifier] NOT NULL,
	[CollectionLastModified] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_COM_Collection] PRIMARY KEY CLUSTERED 
(
	[CollectionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_COM_Collection_CollectionDisplayName] ON [dbo].[COM_Collection]
(
	[CollectionDisplayName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_COM_Collection_CollectionSiteID_CollectionEnabled] ON [dbo].[COM_Collection]
(
	[CollectionSiteID] ASC,
	[CollectionEnabled] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[COM_Collection] ADD  CONSTRAINT [DEFAULT_COM_Collection_CollectionDisplayName]  DEFAULT (N'') FOR [CollectionDisplayName]
GO
ALTER TABLE [dbo].[COM_Collection] ADD  CONSTRAINT [DEFAULT_COM_Collection_CollectionName]  DEFAULT (N'') FOR [CollectionName]
GO
ALTER TABLE [dbo].[COM_Collection] ADD  CONSTRAINT [DEFAULT_COM_Collection_CollectionSiteID]  DEFAULT ((0)) FOR [CollectionSiteID]
GO
ALTER TABLE [dbo].[COM_Collection] ADD  CONSTRAINT [DEFAULT_COM_Collection_CollectionEnabled]  DEFAULT ((1)) FOR [CollectionEnabled]
GO
ALTER TABLE [dbo].[COM_Collection] ADD  CONSTRAINT [DEFAULT_COM_Collection_CollectionGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [CollectionGuid]
GO
ALTER TABLE [dbo].[COM_Collection] ADD  CONSTRAINT [DEFAULT_COM_Collection_CollectionLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [CollectionLastModified]
GO
ALTER TABLE [dbo].[COM_Collection]  WITH CHECK ADD  CONSTRAINT [FK_COM_Collection_CollectionSiteID_CMS_Site] FOREIGN KEY([CollectionSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[COM_Collection] CHECK CONSTRAINT [FK_COM_Collection_CollectionSiteID_CMS_Site]
GO
