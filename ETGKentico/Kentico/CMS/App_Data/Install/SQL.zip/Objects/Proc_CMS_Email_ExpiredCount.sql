SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_CMS_Email_ExpiredCount]
	@Now datetime2(7)
AS
BEGIN
SET NOCOUNT ON;

-- Get default value for number of days to keep archived emails
DECLARE @DefaultDays int = (SELECT CONVERT(int, KeyValue) FROM CMS_SettingsKey WHERE KeyName = 'CMSArchiveEmails' AND SiteID IS NULL)

-- Create a table variable that contains SiteID's and Expiration Dates for archived emails
-- Expiration dates are calculated as today - number of days to archive emails
DECLARE @ExpTable AS TABLE (SiteID int NOT NULL, ExpirationDate datetime2(7) NOT NULL)

-- Insert expiration date for global emails
INSERT INTO @ExpTable VALUES (0, DATEADD(day, - @DefaultDays, @Now))

-- Insert expiration dates for sites
INSERT INTO @ExpTable
	SELECT Sites.SiteID, DATEADD(day, -CONVERT(int, ISNULL(KeyValue, @DefaultDays)), @Now) AS ExpirationDate
	FROM CMS_Site AS Sites LEFT JOIN CMS_SettingsKey AS Settings
	ON Sites.SiteID = Settings.SiteID AND KeyName = 'CMSArchiveEmails'
	WHERE ISNULL(KeyValue, @DefaultDays) > 0

DECLARE @Archived int = 3

-- Get number of expired emails in archive for each site along with the expiration date
SELECT ISNULL(CMS_Email.EmailSiteID, 0) AS SiteID, ExpTable.ExpirationDate AS ExpirationDate, COUNT(*) AS ExpiredEmailsCount
FROM CMS_Email LEFT OUTER JOIN  @ExpTable AS ExpTable ON ISNULL(CMS_Email.EmailSiteID, 0) = ExpTable.SiteID AND EmailStatus = @Archived
WHERE EmailLastSendAttempt <= ExpirationDate
GROUP BY EmailSiteID, ExpTable.ExpirationDate
END
GO
