SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SM_InsightHit_Month](
	[InsightHitID] [int] IDENTITY(1,1) NOT NULL,
	[InsightHitPeriodFrom] [datetime2](7) NOT NULL,
	[InsightHitPeriodTo] [datetime2](7) NOT NULL,
	[InsightHitValue] [bigint] NOT NULL,
	[InsightHitInsightID] [int] NOT NULL,
 CONSTRAINT [PK_SM_InsightHit_Month] PRIMARY KEY CLUSTERED 
(
	[InsightHitID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [UQ_SM_InsightHit_Month_InsightHitInsightID_InsightHitPeriodFrom_InsightHitPeriodTo] ON [dbo].[SM_InsightHit_Month]
(
	[InsightHitInsightID] ASC,
	[InsightHitPeriodFrom] ASC,
	[InsightHitPeriodTo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[SM_InsightHit_Month]  WITH CHECK ADD  CONSTRAINT [FK_SM_InsightHit_Month_SM_Insight_InsightHitInsightID] FOREIGN KEY([InsightHitInsightID])
REFERENCES [dbo].[SM_Insight] ([InsightID])
GO
ALTER TABLE [dbo].[SM_InsightHit_Month] CHECK CONSTRAINT [FK_SM_InsightHit_Month_SM_Insight_InsightHitInsightID]
GO
