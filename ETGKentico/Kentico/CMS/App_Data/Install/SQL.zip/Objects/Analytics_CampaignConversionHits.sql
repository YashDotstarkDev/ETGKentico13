SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Analytics_CampaignConversionHits](
	[CampaignConversionHitsID] [int] IDENTITY(1,1) NOT NULL,
	[CampaignConversionHitsConversionID] [int] NOT NULL,
	[CampaignConversionHitsCount] [int] NOT NULL,
	[CampaignConversionHitsSourceName] [nvarchar](200) NOT NULL,
	[CampaignConversionHitsContentName] [nvarchar](200) NULL,
 CONSTRAINT [PK_Analytics_CampaignConversionHits] PRIMARY KEY CLUSTERED 
(
	[CampaignConversionHitsID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_Analytics_CampaignConversionHits_CampaignConversionHitsConversionID] ON [dbo].[Analytics_CampaignConversionHits]
(
	[CampaignConversionHitsConversionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[Analytics_CampaignConversionHits] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversionHits_CampaignConversionHitsConversionID]  DEFAULT ((0)) FOR [CampaignConversionHitsConversionID]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversionHits] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversionHits_CampaignConversionHitsCount]  DEFAULT ((0)) FOR [CampaignConversionHitsCount]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversionHits] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversionHits_CampaignConversionHitsSourceName]  DEFAULT (N'') FOR [CampaignConversionHitsSourceName]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversionHits]  WITH CHECK ADD  CONSTRAINT [FK_Analytics_CampaignConversionHits_CampaignConversionHitsConversionID_Analytics_CampaignConversion] FOREIGN KEY([CampaignConversionHitsConversionID])
REFERENCES [dbo].[Analytics_CampaignConversion] ([CampaignConversionID])
GO
ALTER TABLE [dbo].[Analytics_CampaignConversionHits] CHECK CONSTRAINT [FK_Analytics_CampaignConversionHits_CampaignConversionHitsConversionID_Analytics_CampaignConversion]
GO
