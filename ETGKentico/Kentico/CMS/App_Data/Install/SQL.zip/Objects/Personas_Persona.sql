SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Personas_Persona](
	[PersonaID] [int] IDENTITY(1,1) NOT NULL,
	[PersonaDisplayName] [nvarchar](200) NOT NULL,
	[PersonaName] [nvarchar](200) NOT NULL,
	[PersonaDescription] [nvarchar](max) NULL,
	[PersonaEnabled] [bit] NOT NULL,
	[PersonaGUID] [uniqueidentifier] NOT NULL,
	[PersonaPictureMetafileGUID] [uniqueidentifier] NULL,
	[PersonaPointsThreshold] [int] NOT NULL,
 CONSTRAINT [PK_Personas_Persona] PRIMARY KEY CLUSTERED 
(
	[PersonaID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
ALTER TABLE [dbo].[Personas_Persona] ADD  CONSTRAINT [DEFAULT_Personas_Persona_PersonaDisplayName]  DEFAULT (N'') FOR [PersonaDisplayName]
GO
ALTER TABLE [dbo].[Personas_Persona] ADD  CONSTRAINT [DEFAULT_Personas_Persona_PersonaName]  DEFAULT (N'[_][_]AUTO[_][_]') FOR [PersonaName]
GO
ALTER TABLE [dbo].[Personas_Persona] ADD  CONSTRAINT [DEFAULT_Personas_Persona_PersonaEnabled]  DEFAULT ((1)) FOR [PersonaEnabled]
GO
ALTER TABLE [dbo].[Personas_Persona] ADD  CONSTRAINT [DEFAULT_Personas_Persona_PersonaPointsThreshold]  DEFAULT ((100)) FOR [PersonaPointsThreshold]
GO
