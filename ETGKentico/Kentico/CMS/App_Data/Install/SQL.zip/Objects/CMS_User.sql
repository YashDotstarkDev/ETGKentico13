SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_User](
	[UserID] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](100) NOT NULL,
	[FirstName] [nvarchar](100) NULL,
	[MiddleName] [nvarchar](100) NULL,
	[LastName] [nvarchar](100) NULL,
	[FullName] [nvarchar](450) NULL,
	[Email] [nvarchar](254) NULL,
	[UserPassword] [nvarchar](100) NOT NULL,
	[PreferredCultureCode] [nvarchar](50) NULL,
	[PreferredUICultureCode] [nvarchar](50) NULL,
	[UserEnabled] [bit] NOT NULL,
	[UserIsExternal] [bit] NULL,
	[UserPasswordFormat] [nvarchar](10) NULL,
	[UserCreated] [datetime2](7) NULL,
	[LastLogon] [datetime2](7) NULL,
	[UserStartingAliasPath] [nvarchar](200) NULL,
	[UserGUID] [uniqueidentifier] NOT NULL,
	[UserLastModified] [datetime2](7) NOT NULL,
	[UserLastLogonInfo] [nvarchar](max) NULL,
	[UserIsHidden] [bit] NULL,
	[UserIsDomain] [bit] NULL,
	[UserHasAllowedCultures] [bit] NULL,
	[UserMFRequired] [bit] NULL,
	[UserPrivilegeLevel] [int] NOT NULL,
	[UserSecurityStamp] [nvarchar](72) NULL,
	[UserMFSecret] [varbinary](max) NULL,
	[UserMFTimestep] [bigint] NULL,
 CONSTRAINT [PK_CMS_User] PRIMARY KEY CLUSTERED 
(
	[UserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_CMS_User_Email] ON [dbo].[CMS_User]
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_CMS_User_FullName] ON [dbo].[CMS_User]
(
	[FullName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_User_UserEnabled_UserIsHidden] ON [dbo].[CMS_User]
(
	[UserEnabled] ASC,
	[UserIsHidden] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CMS_User_UserGUID] ON [dbo].[CMS_User]
(
	[UserGUID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CMS_User_UserName] ON [dbo].[CMS_User]
(
	[UserName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_User_UserPrivilegeLevel] ON [dbo].[CMS_User]
(
	[UserPrivilegeLevel] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_User] ADD  CONSTRAINT [DEFAULT_CMS_User_UserName]  DEFAULT ('') FOR [UserName]
GO
ALTER TABLE [dbo].[CMS_User] ADD  CONSTRAINT [DEFAULT_CMS_User_UserPassword]  DEFAULT (N'') FOR [UserPassword]
GO
ALTER TABLE [dbo].[CMS_User] ADD  CONSTRAINT [DEFAULT_CMS_User_UserEnabled]  DEFAULT ((0)) FOR [UserEnabled]
GO
ALTER TABLE [dbo].[CMS_User] ADD  CONSTRAINT [DEFAULT_CMS_User_UserIsExternal]  DEFAULT ((0)) FOR [UserIsExternal]
GO
ALTER TABLE [dbo].[CMS_User] ADD  CONSTRAINT [DEFAULT_CMS_User_UserIsHidden]  DEFAULT ((0)) FOR [UserIsHidden]
GO
ALTER TABLE [dbo].[CMS_User] ADD  CONSTRAINT [DEFAULT_CMS_User_UserIsDomain]  DEFAULT ((0)) FOR [UserIsDomain]
GO
