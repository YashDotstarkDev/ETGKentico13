SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_AlternativeUrl](
	[AlternativeUrlID] [int] IDENTITY(1,1) NOT NULL,
	[AlternativeUrlGUID] [uniqueidentifier] NOT NULL,
	[AlternativeUrlDocumentID] [int] NOT NULL,
	[AlternativeUrlSiteID] [int] NOT NULL,
	[AlternativeUrlUrl] [nvarchar](400) NOT NULL,
	[AlternativeUrlLastModified] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_CMS_AlternativeUrl] PRIMARY KEY CLUSTERED 
(
	[AlternativeUrlID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_AlternativeUrl_AlternativeUrlDocumentID] ON [dbo].[CMS_AlternativeUrl]
(
	[AlternativeUrlDocumentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CMS_AlternativeUrl_AlternativeUrlSiteID_AlternativeUrlUrl] ON [dbo].[CMS_AlternativeUrl]
(
	[AlternativeUrlSiteID] ASC,
	[AlternativeUrlUrl] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_AlternativeUrl] ADD  CONSTRAINT [DEFAULT_CMS_AlternativeUrl_AlternativeUrlGUID]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [AlternativeUrlGUID]
GO
ALTER TABLE [dbo].[CMS_AlternativeUrl] ADD  CONSTRAINT [DEFAULT_CMS_AlternativeUrl_AlternativeUrlDocumentID]  DEFAULT ((0)) FOR [AlternativeUrlDocumentID]
GO
ALTER TABLE [dbo].[CMS_AlternativeUrl] ADD  CONSTRAINT [DEFAULT_CMS_AlternativeUrl_AlternativeUrlSiteID]  DEFAULT ((0)) FOR [AlternativeUrlSiteID]
GO
ALTER TABLE [dbo].[CMS_AlternativeUrl] ADD  CONSTRAINT [DEFAULT_CMS_AlternativeUrl_AlternativeUrlUrl]  DEFAULT (N'') FOR [AlternativeUrlUrl]
GO
ALTER TABLE [dbo].[CMS_AlternativeUrl] ADD  CONSTRAINT [DEFAULT_CMS_AlternativeUrl_AlternativeUrlLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [AlternativeUrlLastModified]
GO
ALTER TABLE [dbo].[CMS_AlternativeUrl]  WITH CHECK ADD  CONSTRAINT [FK_CMS_AlternativeUrl_CMS_Document] FOREIGN KEY([AlternativeUrlDocumentID])
REFERENCES [dbo].[CMS_Document] ([DocumentID])
GO
ALTER TABLE [dbo].[CMS_AlternativeUrl] CHECK CONSTRAINT [FK_CMS_AlternativeUrl_CMS_Document]
GO
ALTER TABLE [dbo].[CMS_AlternativeUrl]  WITH CHECK ADD  CONSTRAINT [FK_CMS_AlternativeUrl_CMS_Site] FOREIGN KEY([AlternativeUrlSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[CMS_AlternativeUrl] CHECK CONSTRAINT [FK_CMS_AlternativeUrl_CMS_Site]
GO
ALTER TABLE [dbo].[CMS_AlternativeUrl]  WITH CHECK ADD  CONSTRAINT [CHECK_CMS_AlternativeUrl_UniquePath] CHECK  (([dbo].[Func_CMS_Routing_NumberOfCollidingPageUrlPaths]([AlternativeUrlUrl],[AlternativeUrlSiteID])=(0)))
GO
ALTER TABLE [dbo].[CMS_AlternativeUrl] CHECK CONSTRAINT [CHECK_CMS_AlternativeUrl_UniquePath]
GO
