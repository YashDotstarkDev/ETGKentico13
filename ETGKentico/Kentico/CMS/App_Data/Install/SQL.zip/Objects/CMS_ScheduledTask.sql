SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_ScheduledTask](
	[TaskID] [int] IDENTITY(1,1) NOT NULL,
	[TaskName] [nvarchar](200) NOT NULL,
	[TaskDisplayName] [nvarchar](200) NOT NULL,
	[TaskAssemblyName] [nvarchar](200) NOT NULL,
	[TaskClass] [nvarchar](200) NULL,
	[TaskInterval] [nvarchar](1000) NOT NULL,
	[TaskData] [nvarchar](max) NOT NULL,
	[TaskLastRunTime] [datetime2](7) NULL,
	[TaskNextRunTime] [datetime2](7) NULL,
	[TaskLastResult] [nvarchar](max) NULL,
	[TaskSiteID] [int] NULL,
	[TaskDeleteAfterLastRun] [bit] NULL,
	[TaskServerName] [nvarchar](100) NULL,
	[TaskGUID] [uniqueidentifier] NOT NULL,
	[TaskLastModified] [datetime2](7) NOT NULL,
	[TaskExecutions] [int] NULL,
	[TaskResourceID] [int] NULL,
	[TaskRunInSeparateThread] [bit] NULL,
	[TaskUseExternalService] [bit] NULL,
	[TaskAllowExternalService] [bit] NULL,
	[TaskLastExecutionReset] [datetime2](7) NULL,
	[TaskCondition] [nvarchar](400) NULL,
	[TaskRunIndividually] [bit] NULL,
	[TaskUserID] [int] NULL,
	[TaskType] [int] NULL,
	[TaskObjectType] [nvarchar](100) NULL,
	[TaskObjectID] [int] NULL,
	[TaskExecutingServerName] [nvarchar](200) NULL,
	[TaskEnabled] [bit] NOT NULL,
	[TaskIsRunning] [bit] NOT NULL,
	[TaskAvailability] [int] NOT NULL,
 CONSTRAINT [PK_CMS_ScheduledTask] PRIMARY KEY CLUSTERED 
(
	[TaskID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_CMS_ScheduledTask_TaskNextRunTime_TaskEnabled_TaskServerName] ON [dbo].[CMS_ScheduledTask]
(
	[TaskNextRunTime] ASC,
	[TaskEnabled] ASC,
	[TaskServerName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_ScheduledTask_TaskResourceID] ON [dbo].[CMS_ScheduledTask]
(
	[TaskResourceID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_CMS_ScheduledTask_TaskSiteID_TaskDisplayName] ON [dbo].[CMS_ScheduledTask]
(
	[TaskSiteID] ASC,
	[TaskDisplayName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_ScheduledTask_TaskUserID] ON [dbo].[CMS_ScheduledTask]
(
	[TaskUserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_ScheduledTask] ADD  CONSTRAINT [DEFAULT_CMS_ScheduledTask_TaskAllowExternalService]  DEFAULT ((0)) FOR [TaskAllowExternalService]
GO
ALTER TABLE [dbo].[CMS_ScheduledTask] ADD  CONSTRAINT [DEFAULT_CMS_ScheduledTask_TaskExecutingServerName]  DEFAULT (N'') FOR [TaskExecutingServerName]
GO
ALTER TABLE [dbo].[CMS_ScheduledTask] ADD  CONSTRAINT [DEFAULT_CMS_ScheduledTask_TaskEnabled]  DEFAULT ((0)) FOR [TaskEnabled]
GO
ALTER TABLE [dbo].[CMS_ScheduledTask] ADD  CONSTRAINT [DEFAULT_CMS_ScheduledTask_TaskIsRunning]  DEFAULT ((0)) FOR [TaskIsRunning]
GO
ALTER TABLE [dbo].[CMS_ScheduledTask] ADD  CONSTRAINT [DEFAULT_CMS_ScheduledTask_TaskAvailability]  DEFAULT ((0)) FOR [TaskAvailability]
GO
ALTER TABLE [dbo].[CMS_ScheduledTask]  WITH CHECK ADD  CONSTRAINT [FK_CMS_ScheduledTask_TaskResourceID_CMS_Resource] FOREIGN KEY([TaskResourceID])
REFERENCES [dbo].[CMS_Resource] ([ResourceID])
GO
ALTER TABLE [dbo].[CMS_ScheduledTask] CHECK CONSTRAINT [FK_CMS_ScheduledTask_TaskResourceID_CMS_Resource]
GO
ALTER TABLE [dbo].[CMS_ScheduledTask]  WITH CHECK ADD  CONSTRAINT [FK_CMS_ScheduledTask_TaskSiteID_CMS_Site] FOREIGN KEY([TaskSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[CMS_ScheduledTask] CHECK CONSTRAINT [FK_CMS_ScheduledTask_TaskSiteID_CMS_Site]
GO
ALTER TABLE [dbo].[CMS_ScheduledTask]  WITH CHECK ADD  CONSTRAINT [FK_CMS_ScheduledTask_TaskUserID_CMS_User] FOREIGN KEY([TaskUserID])
REFERENCES [dbo].[CMS_User] ([UserID])
GO
ALTER TABLE [dbo].[CMS_ScheduledTask] CHECK CONSTRAINT [FK_CMS_ScheduledTask_TaskUserID_CMS_User]
GO
