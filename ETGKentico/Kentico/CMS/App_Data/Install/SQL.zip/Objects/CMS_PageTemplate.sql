SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_PageTemplate](
	[PageTemplateID] [int] IDENTITY(1,1) NOT NULL,
	[PageTemplateDisplayName] [nvarchar](200) NOT NULL,
	[PageTemplateCodeName] [nvarchar](100) NOT NULL,
	[PageTemplateDescription] [nvarchar](max) NULL,
	[PageTemplateCategoryID] [int] NULL,
	[PageTemplateLayoutID] [int] NULL,
	[PageTemplateWebParts] [nvarchar](max) NULL,
	[PageTemplateLayout] [nvarchar](max) NULL,
	[PageTemplateVersionGUID] [nvarchar](200) NULL,
	[PageTemplateGUID] [uniqueidentifier] NOT NULL,
	[PageTemplateLastModified] [datetime2](7) NOT NULL,
	[PageTemplateType] [nvarchar](10) NOT NULL,
	[PageTemplateLayoutType] [nvarchar](50) NULL,
	[PageTemplateCSS] [nvarchar](max) NULL,
	[PageTemplateThumbnailGUID] [uniqueidentifier] NULL,
	[PageTemplateProperties] [nvarchar](max) NULL,
	[PageTemplateIsLayout] [bit] NULL,
	[PageTemplateIconClass] [nvarchar](200) NULL,
 CONSTRAINT [PK_CMS_PageTemplate] PRIMARY KEY NONCLUSTERED 
(
	[PageTemplateID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE CLUSTERED INDEX [IX_CMS_PageTemplate_PageTemplateCategoryID] ON [dbo].[CMS_PageTemplate]
(
	[PageTemplateCategoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_CMS_PageTemplate_PageTemplateCodeName_PageTemplateDisplayName] ON [dbo].[CMS_PageTemplate]
(
	[PageTemplateCodeName] ASC,
	[PageTemplateDisplayName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_PageTemplate_PageTemplateLayoutID] ON [dbo].[CMS_PageTemplate]
(
	[PageTemplateLayoutID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_PageTemplate] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplate_PageTemplateDisplayName]  DEFAULT ('') FOR [PageTemplateDisplayName]
GO
ALTER TABLE [dbo].[CMS_PageTemplate] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplate_PageTemplateCodeName]  DEFAULT ('') FOR [PageTemplateCodeName]
GO
ALTER TABLE [dbo].[CMS_PageTemplate] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplate_PageTemplateType]  DEFAULT (N'portal') FOR [PageTemplateType]
GO
ALTER TABLE [dbo].[CMS_PageTemplate] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplate_PageTemplateIsLayout]  DEFAULT ((0)) FOR [PageTemplateIsLayout]
GO
ALTER TABLE [dbo].[CMS_PageTemplate] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplate_PageTemplateIconClass]  DEFAULT (N'icon-layout') FOR [PageTemplateIconClass]
GO
ALTER TABLE [dbo].[CMS_PageTemplate]  WITH CHECK ADD  CONSTRAINT [FK_CMS_PageTemplate_PageTemplateCategoryID_CMS_PageTemplateCategory] FOREIGN KEY([PageTemplateCategoryID])
REFERENCES [dbo].[CMS_PageTemplateCategory] ([CategoryID])
GO
ALTER TABLE [dbo].[CMS_PageTemplate] CHECK CONSTRAINT [FK_CMS_PageTemplate_PageTemplateCategoryID_CMS_PageTemplateCategory]
GO
ALTER TABLE [dbo].[CMS_PageTemplate]  WITH CHECK ADD  CONSTRAINT [FK_CMS_PageTemplate_PageTemplateLayoutID_CMS_Layout] FOREIGN KEY([PageTemplateLayoutID])
REFERENCES [dbo].[CMS_Layout] ([LayoutID])
GO
ALTER TABLE [dbo].[CMS_PageTemplate] CHECK CONSTRAINT [FK_CMS_PageTemplate_PageTemplateLayoutID_CMS_Layout]
GO
